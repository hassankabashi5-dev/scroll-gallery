#!/usr/bin/env bash
# يبني ملف APK. يُشغَّل من جذر المشروع.
set -euo pipefail

flutter create --org sd.scrollgallery --project-name scroll_gallery --platforms=android .
python3 tools/patch_android.py
flutter pub get
dart run flutter_launcher_icons
flutter build apk --release --obfuscate --split-debug-info=build/symbols
