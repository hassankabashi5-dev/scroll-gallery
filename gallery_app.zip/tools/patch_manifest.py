#!/usr/bin/env python3
"""يضيف أذونات المعرض والإنترنت واسم التطبيق إلى AndroidManifest.xml
بعد تشغيل: flutter create --platforms=android ."""
import re

PATH = "android/app/src/main/AndroidManifest.xml"

PERMS = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
    <uses-permission android:name="android.permission.READ_MEDIA_VISUAL_USER_SELECTED"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
"""

with open(PATH, encoding="utf-8") as f:
    s = f.read()

if "READ_MEDIA_VIDEO" not in s:
    s = s.replace("<application", PERMS + "    <application", 1)

s = re.sub(r'android:label="[^"]*"', 'android:label="سكرول"', s, count=1)

with open(PATH, "w", encoding="utf-8") as f:
    f.write(s)

print("patched", PATH)
