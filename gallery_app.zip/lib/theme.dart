import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF0D0F1C);
  static const fg = Color(0xFFF4F1EA);
  static const muted = Color(0xFFC3C0D3);
  static const accent = Color(0xFF5AD6B6);
  static const accentInk = Color(0xFF06231D);
  static const glass = Color(0x9E0D0F1C);
  static const line = Color(0x2EF4F1EA);
  static const like = Color(0xFFFF4D6D);
}

const textShadow = [
  Shadow(color: Color(0x73000000), blurRadius: 8, offset: Offset(0, 1)),
];
