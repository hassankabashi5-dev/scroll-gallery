import 'dart:async';
import 'dart:math';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';

import 'format.dart';
import 'media_view.dart';
import 'models.dart';
import 'repository.dart';
import 'theme.dart';

enum SourceFilter { all, phone, web }

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final _repo = Repository();
  final _pages = PageController();
  final _rand = Random();
  StreamSubscription<List<ConnectivityResult>>? _net;

  List<MediaItem> _phone = [];
  final List<MediaItem> _web = Repository.webItems();
  List<MediaItem> _visible = [];
  Set<String> _likes = {};

  bool _loading = true;
  bool _denied = false;
  bool _online = true;
  bool _shuffle = false;
  bool _memories = false;
  bool _muted = false;
  SourceFilter _source = SourceFilter.all;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _net?.cancel();
    _pages.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    _likes = await _repo.loadLikes();
    _online = await _repo.hasInternet();
    _net = Connectivity().onConnectivityChanged.listen((r) {
      final on = !r.contains(ConnectivityResult.none);
      if (on == _online) return;
      _online = on;
      _recompute();
      _toast(on ? 'رجع الإنترنت' : 'ما في إنترنت، عرضنا محتوى الهاتف بس');
    });
    await _loadPhone();
  }

  Future<void> _loadPhone() async {
    setState(() => _loading = true);
    try {
      _phone = await _repo.loadPhone();
      _denied = false;
    } on PermissionDeniedException {
      _denied = true;
    } catch (_) {
      _phone = [];
    }
    _loading = false;
    _recompute();
  }

  /// يعيد بناء القائمة المعروضة حسب المصدر والفلاتر.
  void _recompute() {
    var v = <MediaItem>[
      if (_source != SourceFilter.web) ..._phone,
      if (_source != SourceFilter.phone && _online) ..._web,
    ];
    if (_memories) v = v.where((e) => e.isMemory).toList();
    if (_shuffle) {
      v.shuffle(_rand);
    } else {
      v.sort((a, b) => b.date.compareTo(a.date));
    }
    if (!mounted) return;
    setState(() {
      _visible = v;
      _index = 0;
    });
    if (_pages.hasClients) _pages.jumpToPage(0);
  }

  void _toggleLike() {
    if (_visible.isEmpty) return;
    final id = _visible[_index].id;
    setState(() {
      if (!_likes.remove(id)) _likes.add(id);
    });
    _repo.saveLikes(_likes);
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(m, textAlign: TextAlign.center),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ));
  }

  String get _status {
    final parts = <String>[_shuffle ? 'ترتيب عشوائي' : 'الأحدث أولاً'];
    if (_memories) parts.add('ذكريات مثل اليوم');
    final head = _visible.isEmpty
        ? ''
        : '${arDigits(_index + 1)} / ${arDigits(_visible.length)} · ';
    return head + parts.join(' · ');
  }

  @override
  Widget build(BuildContext context) {
    final liked = _visible.isNotEmpty && _likes.contains(_visible[_index].id);
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _body()),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'سكرول',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w700,
                            shadows: textShadow,
                          ),
                        ),
                        _sourceTabs(),
                      ],
                    ),
                    const SizedBox(height: 8),
                    _chip(_status),
                  ],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: SafeArea(
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Padding(
                  padding: const EdgeInsets.only(left: 12, bottom: 20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _RailButton(
                        icon: Icons.shuffle,
                        label: 'عشوائي',
                        active: _shuffle,
                        onTap: () {
                          _shuffle = !_shuffle;
                          _recompute();
                          _toast(_shuffle ? 'رتبناها عشوائي' : 'رجعنا للأحدث أولاً');
                        },
                      ),
                      const SizedBox(height: 12),
                      _RailButton(
                        icon: Icons.history,
                        label: 'ذكريات',
                        active: _memories,
                        onTap: () {
                          _memories = !_memories;
                          _recompute();
                        },
                      ),
                      const SizedBox(height: 12),
                      _RailButton(
                        icon: liked ? Icons.favorite : Icons.favorite_border,
                        label: liked ? 'أعجبني' : 'إعجاب',
                        active: liked,
                        activeColor: AppColors.like,
                        onTap: _toggleLike,
                      ),
                      const SizedBox(height: 12),
                      _RailButton(
                        icon: _muted ? Icons.volume_off : Icons.volume_up,
                        label: _muted ? 'صامت' : 'الصوت',
                        onTap: () => setState(() => _muted = !_muted),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _body() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_visible.isEmpty) return _empty();
    return PageView.builder(
      scrollDirection: Axis.vertical,
      controller: _pages,
      itemCount: _visible.length,
      onPageChanged: (i) => setState(() => _index = i),
      itemBuilder: (context, i) => MediaView(
        key: ValueKey(_visible[i].id),
        item: _visible[i],
        active: i == _index,
        muted: _muted,
      ),
    );
  }

  Widget _empty() {
    String title;
    String body;
    String action;
    VoidCallback onAction;

    if (_denied && _source != SourceFilter.web) {
      title = 'نحتاج إذن الوصول للمعرض';
      body = 'اسمح للتطبيق بقراءة الصور والفيديوهات عشان نعرضها ليك.';
      action = 'فتح الإعدادات';
      onAction = () => PhotoManager.openSetting();
    } else if (!_online && _source == SourceFilter.web) {
      title = 'ما في إنترنت حالياً';
      body = 'شغّل الإنترنت أو ارجع لمحتوى الهاتف.';
      action = 'عرض الهاتف';
      onAction = () {
        _source = SourceFilter.phone;
        _recompute();
      };
    } else if (_memories) {
      title = 'ما في ذكريات مثل اليوم';
      body = 'ما لقينا صور أو فيديوهات اتصورت في مثل هذا اليوم من السنوات الفاتت.';
      action = 'عرض الكل';
      onAction = () {
        _memories = false;
        _recompute();
      };
    } else {
      title = 'ما في شي هنا';
      body = 'جرّب مصدراً تانياً.';
      action = 'عرض الكل';
      onAction = () {
        _source = SourceFilter.all;
        _recompute();
      };
    }

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title,
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            Text(body,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.muted, height: 1.7)),
            const SizedBox(height: 18),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.accent,
                foregroundColor: AppColors.accentInk,
              ),
              onPressed: onAction,
              child: Text(action),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: AppColors.glass,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: AppColors.line),
        ),
        child: Text(text, style: const TextStyle(fontSize: 12.5)),
      );

  Widget _sourceTabs() {
    const labels = {
      SourceFilter.all: 'الكل',
      SourceFilter.phone: 'الهاتف',
      SourceFilter.web: 'الإنترنت',
    };
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: AppColors.glass,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.line),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final s in SourceFilter.values)
            GestureDetector(
              onTap: () {
                _source = s;
                _recompute();
                if (!_online && s != SourceFilter.phone) {
                  _toast('ما في إنترنت، عرضنا محتوى الهاتف بس');
                }
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: _source == s ? AppColors.accent : Colors.transparent,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  labels[s]!,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight:
                        _source == s ? FontWeight.w600 : FontWeight.w400,
                    color:
                        _source == s ? AppColors.accentInk : AppColors.fg,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _RailButton extends StatelessWidget {
  const _RailButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
    this.activeColor = AppColors.accent,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;
  final Color activeColor;

  @override
  Widget build(BuildContext context) {
    final iconColor = active
        ? (activeColor == AppColors.accent ? AppColors.accentInk : Colors.white)
        : Colors.white;
    return Semantics(
      button: true,
      label: label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: SizedBox(
          width: 56,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: active ? activeColor : AppColors.glass,
                  border: Border.all(
                    color: active ? activeColor : AppColors.line,
                  ),
                ),
                child: Icon(icon, color: iconColor, size: 24),
              ),
              const SizedBox(height: 4),
              Text(label,
                  style: const TextStyle(fontSize: 11, shadows: textShadow)),
            ],
          ),
        ),
      ),
    );
  }
}
