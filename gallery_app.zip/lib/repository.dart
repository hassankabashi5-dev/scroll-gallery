import 'dart:math';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class PermissionDeniedException implements Exception {
  const PermissionDeniedException();
}

class Repository {
  Future<bool> hasInternet() async {
    final r = await Connectivity().checkConnectivity();
    return !r.contains(ConnectivityResult.none);
  }

  /// يقرأ الصور والفيديوهات من معرض الهاتف (آخر 500 عنصر).
  Future<List<MediaItem>> loadPhone() async {
    final perm = await PhotoManager.requestPermissionExtend();
    if (!perm.hasAccess) throw const PermissionDeniedException();

    final paths = await PhotoManager.getAssetPathList(
      onlyAll: true,
      type: RequestType.common,
    );
    if (paths.isEmpty) return [];

    final all = paths.first;
    final count = await all.assetCountAsync;
    final assets = await all.getAssetListRange(start: 0, end: min(count, 500));

    return [
      for (final a in assets)
        if (a.type == AssetType.image || a.type == AssetType.video)
          MediaItem(
            id: 'phone:${a.id}',
            kind: a.type == AssetType.video ? MediaKind.video : MediaKind.image,
            source: MediaSource.phone,
            date: a.createDateTime,
            asset: a,
          ),
    ];
  }

  /// عينات من الإنترنت (صور من picsum وفيديوهات تجريبية من Flutter).
  /// لاحقاً نبدلها بمصدر حقيقي (مثلاً Pexels أو Unsplash).
  static List<MediaItem> webItems() {
    final now = DateTime.now();
    const photoIds = [1015, 1016, 1018, 1019, 1020, 1021, 1022, 1024];
    const videos = [
      'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4',
      'https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4',
    ];
    return [
      for (var i = 0; i < photoIds.length; i++)
        MediaItem(
          id: 'web:photo:${photoIds[i]}',
          kind: MediaKind.image,
          source: MediaSource.web,
          date: now.subtract(Duration(days: 2 + i * 3)),
          title: 'صورة من الإنترنت',
          url: 'https://picsum.photos/id/${photoIds[i]}/800/1400',
        ),
      for (var i = 0; i < videos.length; i++)
        MediaItem(
          id: 'web:video:$i',
          kind: MediaKind.video,
          source: MediaSource.web,
          date: now.subtract(Duration(days: 4 + i * 5)),
          title: 'فيديو من الإنترنت',
          url: videos[i],
        ),
    ];
  }

  Future<Set<String>> loadLikes() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList('likes') ?? const <String>[]).toSet();
  }

  Future<void> saveLikes(Set<String> likes) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('likes', likes.toList());
  }
}
