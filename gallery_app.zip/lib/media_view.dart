import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:video_player/video_player.dart';

import 'format.dart';
import 'models.dart';
import 'theme.dart';

/// صفحة واحدة في السكرول: صورة أو فيديو بملء الشاشة مع التاريخ والشارات.
class MediaView extends StatefulWidget {
  const MediaView({
    super.key,
    required this.item,
    required this.active,
    required this.muted,
  });

  final MediaItem item;
  final bool active;
  final bool muted;

  @override
  State<MediaView> createState() => _MediaViewState();
}

class _MediaViewState extends State<MediaView> {
  VideoPlayerController? _ctrl;
  Future<Uint8List?>? _thumb;
  bool _failed = false;
  bool _paused = false;
  int _token = 0;

  MediaItem get item => widget.item;
  bool get _isVideo => item.kind == MediaKind.video;

  @override
  void initState() {
    super.initState();
    final a = item.asset;
    if (a != null) {
      _thumb = a.thumbnailDataWithSize(const ThumbnailSize(1080, 1920));
    }
    if (widget.active && _isVideo) _startVideo();
  }

  @override
  void didUpdateWidget(MediaView old) {
    super.didUpdateWidget(old);
    if (_isVideo) {
      if (widget.active && !old.active) {
        _paused = false;
        _startVideo();
      } else if (!widget.active && old.active) {
        _stopVideo();
      }
    }
    if (widget.muted != old.muted) {
      _ctrl?.setVolume(widget.muted ? 0 : 1);
    }
  }

  @override
  void dispose() {
    _token++;
    _ctrl?.dispose();
    super.dispose();
  }

  Future<void> _startVideo() async {
    final t = ++_token;
    VideoPlayerController? c;
    try {
      final a = item.asset;
      if (a != null) {
        final f = await a.file;
        if (f == null) throw StateError('no file');
        c = VideoPlayerController.file(f);
      } else {
        c = VideoPlayerController.networkUrl(Uri.parse(item.url!));
      }
      await c.initialize();
      if (!mounted || t != _token) {
        await c.dispose();
        return;
      }
      await c.setLooping(true);
      await c.setVolume(widget.muted ? 0 : 1);
      await c.play();
      setState(() {
        _ctrl = c;
        _failed = false;
      });
    } catch (_) {
      await c?.dispose();
      if (mounted && t == _token) setState(() => _failed = true);
    }
  }

  void _stopVideo() {
    _token++;
    final c = _ctrl;
    _ctrl = null;
    c?.dispose();
  }

  void _toggle() {
    final c = _ctrl;
    if (c == null) return;
    setState(() {
      if (c.value.isPlaying) {
        c.pause();
        _paused = true;
      } else {
        c.play();
        _paused = false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final c = _ctrl;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _isVideo ? _toggle : null,
      child: Stack(
        fit: StackFit.expand,
        children: [
          const ColoredBox(color: AppColors.bg),
          _media(),
          const IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xB3050610),
                    Color(0x00050610),
                    Color(0x00050610),
                    Color(0xD1050610),
                  ],
                  stops: [0, .24, .58, 1],
                ),
              ),
            ),
          ),
          if (_isVideo && _paused)
            const IgnorePointer(
              child: Center(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.glass,
                  ),
                  child: SizedBox(
                    width: 76,
                    height: 76,
                    child: Icon(Icons.play_arrow_rounded, size: 44),
                  ),
                ),
              ),
            ),
          _caption(context),
          if (_isVideo && c != null && c.value.isInitialized)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: VideoProgressIndicator(
                c,
                allowScrubbing: false,
                padding: EdgeInsets.zero,
                colors: const VideoProgressColors(
                  playedColor: AppColors.accent,
                  bufferedColor: Color(0x33F4F1EA),
                  backgroundColor: Color(0x33F4F1EA),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _media() {
    if (_failed) {
      return const Center(
        child: Text(
          'تعذّر تشغيل هذا الملف',
          style: TextStyle(color: AppColors.muted),
        ),
      );
    }
    if (_isVideo) {
      final c = _ctrl;
      return Stack(
        fit: StackFit.expand,
        children: [
          _poster(),
          if (c != null && c.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                clipBehavior: Clip.hardEdge,
                child: SizedBox(
                  width: c.value.size.width,
                  height: c.value.size.height,
                  child: VideoPlayer(c),
                ),
              ),
            )
          else if (widget.active)
            const Center(child: CircularProgressIndicator(strokeWidth: 2)),
        ],
      );
    }
    return _poster();
  }

  Widget _poster() {
    if (item.asset != null) {
      return FutureBuilder<Uint8List?>(
        future: _thumb,
        builder: (context, snap) {
          final d = snap.data;
          if (d == null) return const SizedBox.shrink();
          return Image.memory(d, fit: BoxFit.cover, gaplessPlayback: true);
        },
      );
    }
    if (item.kind == MediaKind.image && item.url != null) {
      return Image.network(
        item.url!,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stack) => const Center(
          child: Icon(Icons.broken_image_outlined,
              color: AppColors.muted, size: 48),
        ),
        loadingBuilder: (context, child, progress) => progress == null
            ? child
            : const Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }
    return const SizedBox.shrink();
  }

  Widget _caption(BuildContext context) {
    final bottom = MediaQuery.of(context).padding.bottom;
    final a = item.asset;
    return Positioned(
      right: 16,
      left: 84,
      bottom: 28 + bottom,
      child: IgnorePointer(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              formatDate(item.date),
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w700,
                height: 1.2,
                shadows: textShadow,
              ),
            ),
            if (item.title.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                item.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 16, shadows: textShadow),
              ),
            ],
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                _Badge(
                  item.source == MediaSource.web ? 'من الإنترنت' : 'من الهاتف',
                  outlined: item.source == MediaSource.web,
                ),
                if (_isVideo)
                  _Badge(a != null && a.videoDuration > Duration.zero
                      ? 'فيديو · ${formatDuration(a.videoDuration)}'
                      : 'فيديو'),
                if (item.isMemory)
                  _Badge('ذكرى · ${yearsLabel(item.yearsAgo)}', memory: true),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge(this.text, {this.memory = false, this.outlined = false});

  final String text;
  final bool memory;
  final bool outlined;

  @override
  Widget build(BuildContext context) {
    final Color bg = memory
        ? AppColors.accent
        : outlined
            ? AppColors.glass
            : const Color(0x2EF4F1EA);
    final Color fg = memory
        ? AppColors.accentInk
        : outlined
            ? AppColors.accent
            : AppColors.fg;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: outlined ? Border.all(color: AppColors.accent) : null,
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: fg,
          fontWeight: memory ? FontWeight.w600 : FontWeight.w400,
        ),
      ),
    );
  }
}
