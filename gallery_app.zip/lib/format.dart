const _months = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

/// يحوّل الأرقام الإنجليزية إلى أرقام عربية.
String arDigits(Object n) {
  const d = '٠١٢٣٤٥٦٧٨٩';
  return n.toString().replaceAllMapped(
        RegExp(r'\d'),
        (m) => d[int.parse(m[0]!)],
      );
}

String formatDate(DateTime d) =>
    '${arDigits(d.day)} ${_months[d.month - 1]} ${arDigits(d.year)}';

String yearsLabel(int n) {
  if (n == 1) return 'قبل سنة';
  if (n == 2) return 'قبل سنتين';
  if (n <= 10) return 'قبل ${arDigits(n)} سنوات';
  return 'قبل ${arDigits(n)} سنة';
}

String formatDuration(Duration d) {
  final m = d.inMinutes;
  final s = (d.inSeconds % 60).toString().padLeft(2, '0');
  return arDigits('$m:$s');
}
