#!/usr/bin/env python3
"""يعدّل مشروع أندرويد الذي ينشئه `flutter create`:
- الأذونات واسم التطبيق
- منع النسخ الاحتياطي التلقائي ومنع الاتصال غير المشفر (HTTP)
- توقيع ثابت للتطبيق إذا وُجدت أسرار KEYSTORE_B64 و KEYSTORE_PASSWORD
"""
import base64
import os
import re
import sys

MANIFEST = "android/app/src/main/AndroidManifest.xml"
PERMS = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
    <uses-permission android:name="android.permission.READ_MEDIA_VISUAL_USER_SELECTED"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
"""


def patch_manifest():
    with open(MANIFEST, encoding="utf-8") as f:
        s = f.read()
    if "READ_MEDIA_VIDEO" not in s:
        s = s.replace("<application", PERMS + "    <application", 1)
    if "android:allowBackup" not in s:
        s = s.replace(
            "<application",
            '<application android:allowBackup="false" '
            'android:usesCleartextTraffic="false"',
            1,
        )
    s = re.sub(r'android:label="[^"]*"', 'android:label="سكرول"', s, count=1)
    with open(MANIFEST, "w", encoding="utf-8") as f:
        f.write(s)
    print("manifest patched")


def write_keystore():
    b64 = os.environ.get("KEYSTORE_B64", "").strip()
    pw = os.environ.get("KEYSTORE_PASSWORD", "").strip()
    if not b64 or not pw:
        print("no signing secrets: release will use the debug key")
        return
    with open("android/app/upload-keystore.jks", "wb") as f:
        f.write(base64.b64decode(b64))
    with open("android/key.properties", "w", encoding="utf-8") as f:
        f.write(
            f"storePassword={pw}\nkeyPassword={pw}\n"
            "keyAlias=scroll\nstoreFile=upload-keystore.jks\n"
        )
    print("keystore written")


KTS_HEAD = """val keystoreProps = java.util.Properties()
val keystoreFile = rootProject.file("key.properties")
if (keystoreFile.exists()) {
    keystoreProps.load(java.io.FileInputStream(keystoreFile))
}

"""

KTS_SIGNING = """    signingConfigs {
        create("release") {
            if (keystoreFile.exists()) {
                keyAlias = keystoreProps["keyAlias"] as String
                keyPassword = keystoreProps["keyPassword"] as String
                storeFile = file(keystoreProps["storeFile"] as String)
                storePassword = keystoreProps["storePassword"] as String
            }
        }
    }

"""

GROOVY_HEAD = """def keystoreProps = new Properties()
def keystoreFile = rootProject.file("key.properties")
if (keystoreFile.exists()) {
    keystoreProps.load(new FileInputStream(keystoreFile))
}

"""

GROOVY_SIGNING = """    signingConfigs {
        release {
            if (keystoreFile.exists()) {
                keyAlias keystoreProps["keyAlias"]
                keyPassword keystoreProps["keyPassword"]
                storeFile file(keystoreProps["storeFile"])
                storePassword keystoreProps["storePassword"]
            }
        }
    }

"""


def patch_gradle():
    kts = "android/app/build.gradle.kts"
    groovy = "android/app/build.gradle"
    if os.path.exists(kts):
        path, is_kts = kts, True
    elif os.path.exists(groovy):
        path, is_kts = groovy, False
    else:
        sys.exit("build.gradle not found")

    with open(path, encoding="utf-8") as f:
        s = f.read()
    if "keystoreProps" in s:
        print("gradle already patched")
        return

    head = KTS_HEAD if is_kts else GROOVY_HEAD
    signing = KTS_SIGNING if is_kts else GROOVY_SIGNING

    # نعرّف الخصائص قبل كتلة android (بدون import لأنها لازم تكون أول الملف)
    m = re.search(r"^android\s*\{", s, re.M)
    if not m:
        sys.exit("android block not found")
    s = s[: m.start()] + head + s[m.start():]

    # كتلة التوقيع قبل buildTypes
    m = re.search(r"^\s*buildTypes\s*\{", s, re.M)
    if not m:
        sys.exit("buildTypes not found")
    s = s[: m.start()] + signing + s[m.start():]

    # استخدام توقيعنا عند وجوده وإلا توقيع debug
    if is_kts:
        new = (
            'signingConfig = if (keystoreFile.exists()) '
            'signingConfigs.getByName("release") '
            'else signingConfigs.getByName("debug")'
        )
        s, n = re.subn(
            r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)', new, s
        )
    else:
        new = (
            "signingConfig keystoreFile.exists() ? "
            "signingConfigs.release : signingConfigs.debug"
        )
        s, n = re.subn(r"signingConfig\s+signingConfigs\.debug", new, s)
    if n == 0:
        sys.exit("release signingConfig line not found")

    with open(path, "w", encoding="utf-8") as f:
        f.write(s)
    print("gradle patched:", path)


if __name__ == "__main__":
    patch_manifest()
    write_keystore()
    patch_gradle()
