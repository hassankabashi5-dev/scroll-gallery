import 'package:photo_manager/photo_manager.dart';

enum MediaKind { image, video }

enum MediaSource { phone, web }

class MediaItem {
  const MediaItem({
    required this.id,
    required this.kind,
    required this.source,
    required this.date,
    this.title = '',
    this.asset,
    this.url,
  });

  final String id;
  final MediaKind kind;
  final MediaSource source;
  final DateTime date;
  final String title;

  /// للعناصر القادمة من معرض الهاتف.
  final AssetEntity? asset;

  /// للعناصر القادمة من الإنترنت.
  final String? url;

  /// ذكرى: نفس اليوم والشهر في سنة سابقة.
  bool get isMemory {
    final n = DateTime.now();
    return date.month == n.month && date.day == n.day && date.year < n.year;
  }

  int get yearsAgo => DateTime.now().year - date.year;
}
